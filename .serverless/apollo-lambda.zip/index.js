"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
require("source-map-support/register");
const apollo_server_lambda_1 = require("apollo-server-lambda");
const apollo_server_core_1 = require("apollo-server-core");
require("reflect-metadata");
const type_graphql_1 = require("type-graphql");
const Items_1 = require("./src/resolvers/Items");
function bootstrap() {
    return __awaiter(this, void 0, void 0, function* () {
        const schema = yield (0, type_graphql_1.buildSchema)({
            resolvers: [Items_1.ItemsResolver],
            // emitSchemaFile: true,
        });
        return new apollo_server_lambda_1.ApolloServer({
            schema,
            csrfPrevention: true,
            cache: 'bounded',
            plugins: [
                (0, apollo_server_core_1.ApolloServerPluginLandingPageLocalDefault)({ embed: true }),
            ],
        });
    });
}
exports.handler = (event, ctx, callback) => __awaiter(void 0, void 0, void 0, function* () {
    return bootstrap()
        .then(server => server.createHandler({ expressGetMiddlewareOptions: {
            cors: {
                origin: '*',
                credentials: true,
            }
        } }))
        .then(handler => handler(event, ctx, callback));
});
//# sourceMappingURL=index.js.map